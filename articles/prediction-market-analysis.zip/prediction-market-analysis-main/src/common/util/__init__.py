from .package import package_data as package_data
from .strings import snake_to_title as snake_to_title
